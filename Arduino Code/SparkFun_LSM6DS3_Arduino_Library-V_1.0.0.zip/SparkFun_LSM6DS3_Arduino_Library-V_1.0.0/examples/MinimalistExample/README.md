Minimalist Example
=======

Basic read function